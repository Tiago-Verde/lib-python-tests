def soma(a, b):
   total = a + b
   return total

def subtracao(a, b):
   total = a - b
   return total